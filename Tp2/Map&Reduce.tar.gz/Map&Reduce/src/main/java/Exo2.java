/**
 * Created by thomas on 10/12/16.
 */

import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;

public class Exo2 {

    public static class Map extends MapReduceBase implements Mapper<LongWritable, Text, IntWritable, IntWritable> {

        public void map(LongWritable key, Text value, OutputCollector<IntWritable, IntWritable> output, Reporter reporter) throws IOException {
            List<String> line = Arrays.asList(value.toString().split(";"));
            List<String> country = Arrays.asList(line.get(2).split(", "));
            List<String> origine = new ArrayList<String>();
            for(int i = 0; i < country.size(); i++){
                origine.addAll(Arrays.asList(country.get(i).split(",")));
            }
            output.collect(new IntWritable(origine.size()), new IntWritable(1));
        }

    }

    public static class Reduce extends MapReduceBase implements Reducer<IntWritable, IntWritable, IntWritable, IntWritable> {

        public void reduce(IntWritable origin, Iterator<IntWritable> iterator, OutputCollector<IntWritable, IntWritable> output, Reporter reporter) throws IOException {
            int nbr = 0;
            while(iterator.hasNext()){
                nbr += iterator.next().get();
            }
            output.collect(origin, new IntWritable(nbr));

        }
    }

    public static void main(String [] args) throws Exception{
        JobConf job = new JobConf(Exo2.class);
        job.setMapperClass(Map.class);
        job.setCombinerClass(Reduce.class);
        job.setReducerClass(Reduce.class);
        job.setOutputKeyClass(IntWritable.class);
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        JobClient.runJob(job);
    }

}
