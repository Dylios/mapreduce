/**
 * Created by thomas on 10/12/16.
 */

import java.util.*;
import java.io.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;



public class Exo3 {


    public static class Map extends Mapper<Object, Text, Text, FloatWritable> {

        private final static FloatWritable one = new FloatWritable(1);
        private final static FloatWritable zero = new FloatWritable(0);

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            List<String> line = Arrays.asList(value.toString().split(";"));
            List<String> sexe = Arrays.asList(line.get(1).split(","));
            for (int i = 0; i < sexe.size(); i++) {
                String sex = sexe.get(i);
                if (sex.equals("m")) {
                    context.write(new Text("m"), one);
                    context.write(new Text("f"), zero);
                } else if (sex.equals("f")) {
                    context.write(new Text("f"), one);
                    context.write(new Text("m"), zero);
                }
            }
        }
    }

    public static class Reduce extends Reducer<Text,FloatWritable,Text,FloatWritable> {

        private FloatWritable percent = new FloatWritable(0);

        public void reduce(Text key, Iterable<FloatWritable> values, Context context) throws IOException, InterruptedException {
            float nbr = 0;
            float nbrtot = 0;

            for (FloatWritable sexe : values){
                nbr += sexe.get();
                ++nbrtot;
            }

            percent.set((nbr/nbrtot)*100);
            context.write(key, percent);
        }
    }


    public static void main(String [] args) throws Exception{
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Map&Reduce");
        job.setJarByClass(Exo3.class);
        job.setMapperClass(Map.class);
        job.setReducerClass(Reduce.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(FloatWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

}
