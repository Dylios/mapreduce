/**
 * Created by thomas on 10/12/16.
 */

import java.io.IOException;
import java.util.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;

public class Exo1 {

    public static class Map extends MapReduceBase implements Mapper<LongWritable, Text, Text, IntWritable> {

        public void map(LongWritable key, Text value, OutputCollector<Text, IntWritable> output, Reporter reporter) throws IOException {
            List<String> line = Arrays.asList(value.toString().split(";"));
            List<String> country = Arrays.asList(line.get(2).split(", "));
            List<String> origine = new ArrayList<String>();
            for(int i = 0; i < country.size(); i++){
                origine.addAll(Arrays.asList(country.get(i).split(",")));
            }
            for (int i = 0; i < origine.size(); i++){
                output.collect(new Text(origine.get(i)), new IntWritable(1));
            }
        }

    }

    public static class Reduce extends MapReduceBase implements Reducer<Text, IntWritable, Text, IntWritable> {

        public void reduce(Text text, Iterator<IntWritable> iterator, OutputCollector<Text, IntWritable> output, Reporter reporter) throws IOException {
            int nbr = 0;
            while(iterator.hasNext()){
                nbr += iterator.next().get();
            }
            output.collect(text, new IntWritable(nbr));

        }
    }

    public static void main(String [] args) throws Exception{
        JobConf job = new JobConf(Exo1.class);
        job.setMapperClass(Map.class);
        job.setCombinerClass(Reduce.class);
        job.setReducerClass(Reduce.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        JobClient.runJob(job);
    }

}
